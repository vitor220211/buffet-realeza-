<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep Buffet Realeza proposals in shared browser-safe data modules without price fields; both event forms and catalog pages use the same options to avoid inconsistent quotes.
- Use separate TanStack leaf routes for menu personalization, Kids and tasting, with a shared site header, so each experience has a shareable URL.
- Event requests are composed client-side and opened in WhatsApp; do not persist personal event details or invent replacement prices because the buffet quotes them directly.
- Derive the favicon from the supplied brand logo and preserve owners' photo at its original aspect ratio.
- Keep Vite's outdated dependency request rejection enabled so optimization changes trigger a full reload instead of mixing React instances in an already-open preview.
