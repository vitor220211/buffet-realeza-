import { Link, createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Send } from "lucide-react";
import { Button } from '@/components/ui/button';
import { PhotoGallery } from '@/components/buffet/photo-gallery';
import { propostas, welcome } from '@/lib/buffet-data';
import { TASTING, whatsappUrl } from '@/lib/event-quote';
import { TastingForm } from '@/components/buffet/scheduling-form';
import capa from '@/assets/novas/capa.jpg.asset.json';
import donos from "@/assets/donos.png.asset.json";
import logoRealeza from '@/assets/novas/logo-realeza.png.asset.json';

const fotoMods = import.meta.glob("@/assets/fotos/*.asset.json", { eager: true }) as Record<string, { default: { url: string } }>;
const fotos = Object.keys(fotoMods)
  .sort((a, b) => Number(a.match(/(\d+)\./)?.[1] ?? 0) - Number(b.match(/(\d+)\./)?.[1] ?? 0))
  .map((k) => fotoMods[k]?.default.url)
  .filter((u): u is string => Boolean(u));

const WHATS = whatsappUrl("Olá! Gostaria de fazer um orçamento com o Buffet Realeza.");
const comidaMods = import.meta.glob('@/assets/novas/WhatsApp*.asset.json', { eager: true }) as Record<string, { default: { url: string } }>;
const comidas = Object.values(comidaMods).map(m => m.default.url);
const ENDERECO = "Av. Carlos Gomes, 51 - Centro, Agudos - SP, 17129-016";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Buffet Realeza | Buffet e Salão de Festas em Agudos-SP" },
      { name: "description", content: "Mais de 10 anos e 1000 eventos entregues. Buffet completo, prataria própria e salão aconchegante em Agudos-SP." },
      { property: "og:title", content: "Buffet Realeza | Buffet em Agudos-SP" },
      { property: "og:description", content: "Mais de 10 anos e 1000 eventos entregues. Peça seu orçamento pelo WhatsApp." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function useReveal() {
  useEffect(() => {
    const io = new IntersectionObserver((es) => es.forEach((e) => e.isIntersecting && (e.target.classList.add("in"), io.unobserve(e.target))), { threshold: 0.12 });
    document.querySelectorAll(".reveal").forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);
}

function Counter({ to, suffix = "" }: { to: number; suffix?: string }) {
  const [n, setN] = useState(0);
  useEffect(() => {
    let raf = 0; const start = performance.now();
    const tick = (t: number) => { const p = Math.min((t - start) / 2000, 1); setN(Math.round(to * (1 - Math.pow(1 - p, 3)))); if (p < 1) raf = requestAnimationFrame(tick); };
    raf = requestAnimationFrame(tick); return () => cancelAnimationFrame(raf);
  }, [to]);
  return <>{n}{suffix}</>;
}

function WhatsIcon({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden>
      <path d="M17.5 14.4c-.3-.1-1.7-.8-2-.9-.3-.1-.5-.1-.7.1-.2.3-.8.9-.9 1.1-.2.2-.3.2-.6.1-.3-.1-1.2-.5-2.3-1.4-.9-.8-1.4-1.7-1.6-2-.2-.3 0-.5.1-.6l.4-.5c.1-.2.2-.3.3-.5.1-.2 0-.4 0-.5l-.9-2.2c-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.5.1-.8.4-.3.3-1 1-1 2.4s1 2.8 1.2 3c.1.2 2 3.1 4.9 4.3 2.4 1 2.9.8 3.4.7.5-.1 1.7-.7 2-1.4.2-.7.2-1.2.2-1.4-.1-.1-.3-.2-.6-.3zM12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm0 18.2c-1.5 0-3-.4-4.3-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2z" />
    </svg>
  );
}

function Index() {
  useReveal();

  const hero = capa.url;

  return (
    <div className="overflow-x-hidden">
      {/* Início */}
      <section id="inicio" className="relative flex min-h-[76svh] py-20 items-center justify-center overflow-hidden">
        <img src={hero} alt="Evento Buffet Realeza" className="kenburns absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/50 to-background" />
        <div className="relative z-10 px-6 text-center">
          <img src={logoRealeza.url} alt="Logo Buffet Realeza" className="fadeup mx-auto mb-8 h-36 w-36 rounded-full shadow-2xl md:h-44 md:w-44" style={{ animationDelay: ".1s" }} />
          <p className="fadeup text-xs uppercase tracking-[0.5em] text-primary">Buffet & Salão de Festas · Agudos-SP</p>
          <h1 className="fadeup mt-6 font-display text-6xl leading-none md:text-8xl" style={{ animationDelay: ".2s" }}>
            <span className="text-4xl md:text-6xl">Buffet</span><br /><span className="gold-text italic">Realeza</span>
          </h1>
          <p className="fadeup mx-auto mt-8 max-w-xl text-lg text-muted-foreground" style={{ animationDelay: ".4s" }}>
            Há mais de 10 anos transformando celebrações em memórias inesquecíveis.
          </p>
          <div className="fadeup mt-10 flex flex-wrap justify-center gap-4" style={{ animationDelay: ".6s" }}>
            <Button asChild size="lg" className="h-auto py-4"><Link to="/personalize"><WhatsIcon /> Planejar meu evento</Link></Button>
            <a href="#cardapios" className="rounded-full border border-foreground/30 px-8 py-4 text-sm uppercase tracking-widest transition hover:border-primary hover:text-primary">Ver cardápios</a>
          </div>
        </div>
        <div className="absolute bottom-8 left-1/2 h-12 w-px -translate-x-1/2 animate-pulse bg-primary" />
      </section>

      {/* Números */}
      <section className="border-y bg-card py-16">
        <div className="mx-auto grid max-w-5xl grid-cols-1 gap-10 px-6 text-center sm:grid-cols-3">
          {[[<Counter key="a" to={10} />, "Anos realizando grandes eventos"], [<Counter key="b" to={1000} suffix="+" />, "Eventos entregues e o próximo pode ser o seu"], ["Diversos", "Cardápios para você escolher o melhor"]].map(([n, l], i) => (
            <div key={i} className="reveal" style={{ transitionDelay: `${i * 0.15}s` }}>
              <div className="font-display text-6xl text-primary">{n}</div>
              <div className="mt-2 text-sm uppercase tracking-widest text-muted-foreground">{l}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Sobre */}
      <section id="sobre" className="py-28">
        <div className="mx-auto grid max-w-6xl items-center gap-16 px-6 md:grid-cols-2">
          <div className="reveal relative mx-auto w-full max-w-[380px]">
            <div className="absolute -inset-4 translate-x-6 translate-y-6 border border-primary/40" />
            <img src={donos.url} alt="Os proprietários da Buffet Realeza" className="relative block h-auto w-full" />
          </div>
          <div className="reveal" style={{ transitionDelay: ".2s" }}>
            <p className="text-xs uppercase tracking-[0.4em] text-primary">Quem somos</p>
            <h2 className="mt-4 font-display text-5xl">Uma família que vive para <em className="gold-text">celebrar</em> a sua</h2>
            <p className="mt-6 leading-relaxed text-muted-foreground">
              Somos a Buffet Realeza. Há mais de 10 anos nos dedicamos exclusivamente ao ramo de buffet, cuidando de cada detalhe com carinho e excelência. Já são mais de 1000 eventos entregues — casamentos, 15 anos, aniversários, bodas, corporativos e formaturas.
            </p>
            <p className="mt-4 leading-relaxed text-muted-foreground">
              Cada evento é tratado como se fosse nosso: atendimento próximo, cardápios pensados para você e uma equipe que faz tudo acontecer para que você só aproveite.
            </p>
            <a href={WHATS} target="_blank" rel="noreferrer" className="mt-8 inline-flex items-center gap-2 border-b border-primary pb-1 text-primary">
              <WhatsIcon className="h-4 w-4" /> Converse com a gente
            </a>
          </div>
        </div>
      </section>

      {/* Estrutura */}
      <section id="estrutura" className="bg-card py-28">
        <div className="mx-auto max-w-6xl px-6">
          <div className="reveal text-center">
            <p className="text-xs uppercase tracking-[0.4em] text-primary">Nossa estrutura</p>
            <h2 className="mt-4 font-display text-5xl">Infraestrutura completa para o seu evento</h2>
          </div>
          <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {[
              ["Salão de eventos", "Espaço Açucena da Serra para o seu evento se tornar único e inesquecível. Um salão espaçoso e aconchegante em Agudos."],
              ["Prataria própria", "Trazendo requinte e sofisticação para você."],
              ["Cardápios diversos", "Do jantar sofisticado ao festival de massas e espetinhos: escolha o melhor para o seu evento."],
            ].map(([t, d], i) => (
              <div key={t} className="reveal group border bg-background p-8 transition duration-500 hover:-translate-y-2 hover:border-primary" style={{ transitionDelay: `${(i % 3) * 0.12}s` }}>
                <div className="font-display text-4xl text-primary/60 transition group-hover:text-primary">0{i + 1}</div>
                <h3 className="mt-4 font-display text-2xl">{t}</h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Cardápios */}
      <section id="cardapios" className="py-28">
        <div className="mx-auto max-w-7xl px-6">
          <div className="reveal text-center">
            <p className="text-xs uppercase tracking-[0.4em] text-primary">Coleção Gastronômica 2026 – 2027</p>
            <h2 className="mt-4 font-display text-5xl">Nossas propostas</h2>
            <p className="mx-auto mt-6 max-w-2xl text-muted-foreground">
              Todas incluem Welcome Drink e bebidas servidas em baldes de gelo: {welcome.join(" • ")}.
            </p>
          </div>
          <div className="mt-16 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {propostas.map((p, i) => (
              <article key={p.nome} className={`reveal relative flex flex-col border bg-card p-8 transition duration-500 hover:-translate-y-2 hover:shadow-2xl ${p.destaque ? "border-primary" : ""}`} style={{ transitionDelay: `${(i % 3) * 0.12}s` }}>
                {p.destaque && <span className="absolute -top-3 left-8 bg-primary px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-primary-foreground">Mais completa</span>}
                <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">Proposta</p>
                <h3 className="font-display text-4xl italic text-primary">{p.nome}</h3>
                <div className="mt-6 flex-1 space-y-4">
                  {p.secoes.map(([t, d]) => (
                    <div key={t}>
                      <h4 className="text-sm font-semibold uppercase tracking-wider">{t}</h4>
                      <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{d}</p>
                    </div>
                  ))}
                </div>
                <Button asChild className="mt-8 h-auto min-h-12 whitespace-normal py-3"><Link to="/personalize" search={{ proposta: p.nome }}>Escolher e personalizar</Link></Button>
              </article>
            ))}
          </div>
          <div className="mt-12 text-center"><Button asChild variant="outline" size="lg"><Link to="/personalize">Personalize seu cardápio</Link></Button></div>
        </div>
      </section>

      {/* Agendamento de degustação */}
      <section id="agendar-degustacao" className="bg-card py-28">
        <div className="mx-auto grid max-w-6xl items-center gap-16 px-6 md:grid-cols-2">
          <div className="reveal">
            <p className="text-xs uppercase tracking-[0.4em] text-primary">Degustação</p>
            <h2 className="mt-4 font-display text-5xl">Prove antes de <em className="gold-text">celebrar</em></h2>
            <p className="mt-6 leading-relaxed text-muted-foreground">
              Uma experiência exclusiva para o casal conhecer de perto os sabores do nosso buffet: entrada, prato principal e sobremesa.
            </p>
            <p className="mt-4 leading-relaxed text-muted-foreground">
              Investimento de {TASTING.pricePerCouple.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })} por casal, integralmente descontado do contrato ao fechar seu evento.
            </p>
            <p className="mt-4 text-sm uppercase tracking-widest text-primary">Exclusivamente mediante agendamento prévio</p>
          </div>
          <TastingForm />
        </div>
      </section>

      <section className="border-y bg-card py-20"><div className="mx-auto grid max-w-6xl gap-12 px-6 md:grid-cols-2"><div><p className="text-primary">Realeza Kids</p><h2 className="mt-3 font-display text-4xl">É divertido comemorar!</h2><p className="mt-4 text-muted-foreground">Pacotes exclusivos com gastronomia, decoração e diversão para celebrar a infância.</p><Button asChild className="mt-6"><Link to="/kids">Conhecer Eventos Kids</Link></Button></div><div><p className="text-primary">Uma experiência a dois</p><h2 className="mt-3 font-display text-4xl">Conheça nossa degustação</h2><p className="mt-4 text-muted-foreground">Entrada, prato principal e sobremesa. R$ 200,00 por casal, integralmente descontados do contrato ao fechar seu evento.</p><Button asChild variant="outline" className="mt-6"><Link to="/degustacao">Agendar degustação</Link></Button></div></div></section>

      {/* Galeria */}
      <section id="galeria" className="bg-card py-28">
        <div className="mx-auto max-w-7xl px-6">
          <div className="reveal text-center">
            <p className="text-xs uppercase tracking-[0.4em] text-primary">Galeria</p>
            <h2 className="mt-4 font-display text-5xl">Momentos que criamos</h2>
          </div>
          <div className="mt-12"><PhotoGallery photos={fotos.filter((_, i) => ![0, 2, 3, 5, 11, 14, 19, 20, 21].includes(i))} label="Evento Buffet Realeza" /></div>
        </div>
      </section>
      <section id="gastronomia" className="py-24"><div className="mx-auto max-w-7xl px-6"><div className="reveal mb-12 text-center"><p className="text-xs uppercase tracking-widest text-primary">Nossa gastronomia</p><h2 className="mt-4 font-display text-5xl">Sabores que celebram</h2></div><PhotoGallery photos={comidas} label="Gastronomia Buffet Realeza" /></div></section>

      {/* Contato */}
      <section id="contato" className="relative overflow-hidden py-28">
        <img src={fotos[5] ?? hero} alt="" className="absolute inset-0 h-full w-full object-cover opacity-20" />
        <div className="relative mx-auto max-w-4xl px-6 text-center">
          <h2 className="reveal font-display text-5xl md:text-6xl">Vamos realizar o seu <em className="gold-text">evento dos sonhos?</em></h2>
          <p className="reveal mt-6 text-muted-foreground">Escolha a proposta e conte os detalhes do seu evento.</p>
          <a href={WHATS} target="_blank" rel="noreferrer" className="reveal mt-10 inline-flex items-center gap-3 rounded-full bg-whats px-10 py-5 text-lg font-semibold text-primary-foreground transition hover:scale-105">
            <WhatsIcon className="h-6 w-6" /> (14) 98218-2008
          </a>
          <div className="reveal mt-16 grid gap-8 text-left sm:grid-cols-2">
            <div className="border bg-card/80 p-6">
              <h3 className="font-display text-2xl text-primary">Endereço</h3>
              <p className="mt-2 text-muted-foreground">{ENDERECO}</p>
            </div>
            <iframe title="Mapa" className="h-48 w-full border" loading="lazy" src={`https://www.google.com/maps?q=${encodeURIComponent(ENDERECO)}&output=embed`} />
          </div>
        </div>
      </section>

      <footer className="border-t py-8 text-center text-sm text-muted-foreground">
        © {new Date().getFullYear()} Buffet Realeza · Agudos-SP
      </footer>

      <Link to="/personalize" aria-label="Orçamento pelo WhatsApp" className="pulse fixed bottom-6 right-6 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-whats text-primary-foreground transition hover:scale-110">
        <WhatsIcon className="h-7 w-7" />
      </Link>
    </div>
  );
}
