import { Link, createFileRoute } from '@tanstack/react-router';
import { useState } from 'react';
import { PartyPopper, CakeSlice, Sparkles, Utensils } from 'lucide-react';
import kidsLogo from '@/assets/novas/kids-logo.png.asset.json';
import { Button } from '@/components/ui/button';
import { QuoteForm } from '@/components/buffet/quote-form';
import { KidsScheduleForm } from '@/components/buffet/scheduling-form';
import { KIDS_EXCLUSIVE_PACKAGE } from '@/lib/kids-data';
export const Route = createFileRoute('/kids')({
  head: () => ({ meta: [
    { title: 'Eventos Kids | Buffet Realeza' }, { name: 'description', content: 'Realeza Kids: pacotes exclusivos com gastronomia, decoração e brinquedos para aniversários infantis em Agudos-SP.' },
    { property: 'og:title', content: 'Realeza Kids | É divertido comemorar' }, { property: 'og:description', content: 'Faça sua festa infantil com o Buffet Realeza: pacotes exclusivos para celebrar a infância.' },
    { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary_large_image' },
  ] }), component: Kids,
});
function Kids() {
  const [proposal, setProposal] = useState('');
  return <main>
    <section className="kids-intro border-b py-12 sm:py-16"><div className="mx-auto max-w-6xl px-6 text-center"><img src={kidsLogo.url} alt="Realeza Kids — É divertido comemorar" className="mx-auto w-full max-w-sm object-contain" /><p className="mt-8 text-xs uppercase tracking-widest text-primary">Aqui seu sonho se torna realidade</p><h1 className="mt-3 font-display text-5xl">Eventos Kids</h1><p className="mx-auto mt-5 max-w-xl text-muted-foreground">Uma festa cheia de sabores, carinho e diversão para os pequenos.</p></div></section>
    <section className="mx-auto max-w-7xl px-6 py-16"><div id="pacotes-kids" className="kids-pink rounded-md border bg-card px-6 py-12 text-center sm:px-12"><p className="text-xs uppercase tracking-widest text-muted-foreground">Pacotes exclusivos</p><h2 className="kids-accent mt-3 font-display text-4xl sm:text-5xl">Faça sua festa infantil com a gente</h2><p className="mx-auto mt-5 max-w-2xl leading-relaxed text-muted-foreground">Cada festa nasce do jeito da criança: cardápio, decoração, brinquedos e toda a equipe do Buffet Realeza cuidando de cada detalhe. Clique abaixo e receba os pacotes exclusivos no WhatsApp.</p><Button size="lg" className="mt-8 h-auto min-h-12 whitespace-normal py-3" onClick={() => { setProposal(KIDS_EXCLUSIVE_PACKAGE); document.getElementById('orcamento-kids')?.scrollIntoView({ behavior: 'smooth' }); }}><CakeSlice className="h-5 w-5" /> Quero os pacotes exclusivos</Button></div>
    <div className="mt-12 grid gap-8 border-y py-10 md:grid-cols-3">{[[PartyPopper, 'Diversão incluída', '2 pula-pulas, espaço baby, piscina de bolinhas e tombo legal.'], [Sparkles, 'Uma festa do seu jeito', 'Decoração com tema à escolha, papelaria e caixinha surpresa personalizadas com o tema e a identidade do aniversariante.'], [Utensils, 'Cuidado em cada detalhe', 'Salgados fritos na hora, ketchup, sousplat, pratos, guardanapos, taças e toalhas de mesa.']].map(([Icon, title, description]) => { const I = Icon as typeof PartyPopper; return <div key={String(title)}><I className="h-6 w-6 text-primary" /><h3 className="mt-4 font-display text-2xl">{String(title)}</h3><p className="mt-3 text-sm leading-relaxed text-muted-foreground">{String(description)}</p></div>; })}</div>
    <p className="mt-6 text-center text-sm text-muted-foreground">Mínimo de 80 pessoas pagantes inteiras. Crianças de 0 a 3 anos não pagam. Crianças de 4 a 8 anos pagam meia.</p>
    </section>
    <section id="agendar-kids" className="border-t py-16"><div className="mx-auto grid max-w-6xl items-center gap-12 px-6 md:grid-cols-2"><div><p className="text-xs uppercase tracking-widest text-primary">Agendamento</p><h2 className="mt-4 font-display text-4xl">Escolha a data e o horário</h2><p className="mt-4 leading-relaxed text-muted-foreground">Escolha uma data e um horário disponíveis para a festa dos pequenos e envie o pedido pelo WhatsApp — o Buffet Realeza confirma a disponibilidade.</p></div><KidsScheduleForm /></div></section>
    <section id="orcamento-kids" className="border-t bg-card py-16"><div className="mx-auto max-w-3xl px-6"><p className="text-xs uppercase tracking-widest text-primary">Sua próxima comemoração</p><h2 className="mt-4 font-display text-4xl">Planeje a festa dos pequenos</h2><div className="mt-10"><QuoteForm key={proposal} initialProposal={proposal} kids /></div></div></section>
  </main>;
}
