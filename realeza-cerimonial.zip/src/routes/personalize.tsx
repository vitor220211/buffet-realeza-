import { createFileRoute } from '@tanstack/react-router';
import { QuoteForm } from '@/components/buffet/quote-form';
export const Route = createFileRoute('/personalize')({
  validateSearch: (s: Record<string, unknown>): { proposta?: string } => typeof s['proposta'] === 'string' ? { proposta: s['proposta'] } : {},
  head: () => ({ meta: [
    { title: 'Personalize seu Cardápio | Buffet Realeza' },
    { name: 'description', content: 'Escolha sua proposta, personalize entradas e sobremesas e solicite seu orçamento ao Buffet Realeza pelo WhatsApp.' },
    { property: 'og:title', content: 'Personalize seu Cardápio | Buffet Realeza' },
    { property: 'og:description', content: 'Seu evento, suas escolhas. Monte seu cardápio e solicite um orçamento personalizado.' },
    { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary_large_image' },
  ] }),
  component: Personalize,
});
function Personalize() {
  const { proposta } = Route.useSearch();
  return <main className="mx-auto max-w-3xl px-6 py-16 sm:py-24"><p className="text-xs uppercase tracking-widest text-primary">Um evento com a sua essência</p><h1 className="mt-4 font-display text-5xl">Personalize seu cardápio</h1><div className="mt-12"><QuoteForm key={proposta} initialProposal={proposta ?? ''} /></div></main>;
}