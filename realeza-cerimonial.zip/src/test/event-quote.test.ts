import { describe, expect, it } from 'vitest';
import { quoteMessage, whatsappUrl, TASTING, kidsBillingWeight, KIDS_MINIMUM_PAYING_GUESTS } from '@/lib/event-quote';
import { propostas } from '@/lib/buffet-data';

describe('Buffet Realeza event requests', () => {
  it('sends date, guest count, place, chosen proposal and changes to the owner', () => {
    const message = quoteMessage({ name: 'Vitor', date: '2026-12-19', guests: '100', location: 'Agudos, Espaço Açucena da Serra', eventType: 'Casamento', proposal: 'Diamante', changes: ['Trocar a sobremesa por brownie com sorvete'], notes: 'Retirar kibe cru' });
    const url = new URL(whatsappUrl(message));
    expect(url.pathname).toBe('/5514982182008');
    expect(url.searchParams.get('text')).toContain('Data do evento: 19/12/2026');
    expect(message).toContain('Quantidade de convidados: 100');
    expect(message).toContain('Local do evento: Agudos, Espaço Açucena da Serra');
    expect(message).toContain('Proposta escolhida: Diamante');
    expect(message).toContain('Trocar a sobremesa por brownie com sorvete');
    expect(message).toContain('Retirar kibe cru');
  });
  it('keeps all seven menu options without prices', () => {
    expect(propostas.map(p => p.nome)).toEqual(['Diamante', 'Gold', 'Experiência', 'Brasa', 'Itália', 'Bistrô Brasileiro', 'Prata']);
    expect(propostas.some(p => 'precos' in p)).toBe(false);
  });
  it('charges R$ 200 per couple for tasting', () => { expect(TASTING.pricePerCouple).toBe(200); });
  it('deducts the full R$ 200 tasting payment from the event contract', () => { expect(TASTING.contractCredit).toBe(200); expect(TASTING.contractCredit).toBe(TASTING.pricePerCouple); });
  it('requires prior booking for tasting', () => { expect(TASTING.appointmentRequired).toBe(true); });
  it('does not charge Kids guests from zero through three years', () => { expect([0, 1, 2, 3].map(kidsBillingWeight)).toEqual([0, 0, 0, 0]); });
  it('charges half for Kids guests from four through eight years', () => { expect([4, 5, 6, 7, 8].map(kidsBillingWeight)).toEqual([0.5, 0.5, 0.5, 0.5, 0.5]); expect(kidsBillingWeight(9)).toBe(1); });
  it('requires at least 80 full-paying Kids guests', () => { expect(KIDS_MINIMUM_PAYING_GUESTS).toBe(80); });
});