import { useState } from 'react';
import { Send, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { propostas } from '@/lib/buffet-data';
import { kidsProposalOptions } from '@/lib/kids-data';
import { quoteMessage, whatsappUrl, type EventQuote, KIDS_MINIMUM_PAYING_GUESTS } from '@/lib/event-quote';

export function QuoteForm({ initialProposal = '', kids = false }: { initialProposal?: string; kids?: boolean }) {
  const [quote, setQuote] = useState<EventQuote>({ name: '', date: '', guests: '', location: '', eventType: kids ? 'Aniversário infantil' : '', proposal: initialProposal, changes: [], notes: '', childrenFree: '', childrenHalf: '' });
  const [sent, setSent] = useState(false);
  function update(key: keyof EventQuote, value: string) { setSent(false); setQuote(q => ({ ...q, [key]: value })); }
  return <form onSubmit={e => { e.preventDefault(); window.open(whatsappUrl(quoteMessage(quote)), '_blank', 'noopener,noreferrer'); setSent(true); }} className="quote-form">
    <div className="grid gap-6 sm:grid-cols-2">
      <label>Seu nome<input required autoComplete="name" value={quote.name} onChange={e => update('name', e.target.value)} /></label>
      <label>Data do evento<input required type="date" value={quote.date} onChange={e => update('date', e.target.value)} /></label>
      <label>{kids ? 'Convidados pagantes inteiros' : 'Quantidade de convidados'}<input required type="number" min={kids ? KIDS_MINIMUM_PAYING_GUESTS : 1} value={quote.guests} onChange={e => update('guests', e.target.value)} /></label>
      <label>Tipo de evento<select required value={quote.eventType} onChange={e => update('eventType', e.target.value)}><option value="">Selecione</option>{['Casamento', '15 anos', 'Aniversário', 'Bodas', 'Corporativo', 'Formatura', 'Aniversário infantil', 'Outro'].map(t => <option key={t}>{t}</option>)}</select></label>
      <label className="sm:col-span-2">Local do evento<input required placeholder="Nome do espaço, cidade e endereço" value={quote.location} onChange={e => update('location', e.target.value)} /></label>
      <label className="sm:col-span-2">Proposta escolhida<select required value={quote.proposal} onChange={e => update('proposal', e.target.value)}><option value="">Selecione sua proposta</option>{(kids ? kidsProposalOptions : propostas.map(p => p.nome)).map(p => <option key={p}>{p}</option>)}</select></label>
      {kids && <><label>Crianças de 0 a 3 anos<input type="number" min="0" value={quote.childrenFree} onChange={e => update('childrenFree', e.target.value)} /></label><label>Crianças de 4 a 8 anos<input type="number" min="0" value={quote.childrenHalf} onChange={e => update('childrenHalf', e.target.value)} /></label></>}
    </div>
    <label className="mt-10 block"><span className="font-display text-3xl">Escolha o que quer no seu cardápio</span><textarea rows={5} className="mt-5" placeholder="Escreva do seu jeito o que quer no cardápio: o que manter, trocar, retirar ou acrescentar." value={quote.notes} onChange={e => update('notes', e.target.value)} /></label>
    <p className="mt-4 text-sm text-muted-foreground">Os valores da proposta, dos acréscimos e das trocas serão informados pelo Buffet Realeza.</p>
    <div className="mt-8 border-t pt-6"><h3 className="text-sm uppercase tracking-widest text-primary">Suas escolhas</h3><p className="mt-3 font-display text-2xl">{quote.proposal || 'Proposta a escolher'}</p>{quote.notes && <p className="mt-2 whitespace-pre-wrap text-muted-foreground">{quote.notes}</p>}</div>
    <Button type="submit" size="lg" className="mt-8 h-auto min-h-12 w-full whitespace-normal py-3"><Send /> Enviar orçamento pelo WhatsApp</Button>
    {sent && <p role="status" className="mt-4 flex items-center gap-2 text-primary"><Check className="h-4 w-4" />Mensagem preparada. Confirme o envio no WhatsApp.</p>}
  </form>;
}