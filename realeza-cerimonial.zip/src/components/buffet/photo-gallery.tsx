import { useState } from 'react';
import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
export function PhotoGallery({ photos, label }: { photos: string[]; label: string }) {
  const [selected, setSelected] = useState<string | null>(null);
  return <><div className="grid grid-cols-2 gap-3 md:grid-cols-3">{photos.map((src, i) => <Button variant="ghost" key={src} onClick={() => setSelected(src)} className="group h-auto aspect-[4/3] w-full overflow-hidden rounded-none p-0" aria-label={`Ampliar ${label} ${i + 1}`}><img src={src} alt={`${label} ${i + 1}`} loading="lazy" className="h-full w-full object-cover transition duration-700 group-hover:scale-105" /></Button>)}</div><Dialog open={Boolean(selected)} onOpenChange={open => !open && setSelected(null)}><DialogContent className="max-w-4xl border-0 bg-background p-3"><DialogTitle className="sr-only">{label}</DialogTitle>{selected && <img src={selected} alt={label} className="max-h-[80vh] w-full object-contain" />}</DialogContent></Dialog></>;
}