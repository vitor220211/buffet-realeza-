import { useState, type FormEvent } from 'react';
import { Send, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { TASTING, whatsappUrl } from '@/lib/event-quote';

const TIMES = ['09:00', '10:00', '11:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00'];

function useSchedule() {
  const [name, setName] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [notes, setNotes] = useState('');
  const [sent, setSent] = useState(false);
  const fmt = (d: string) => d.split('-').reverse().join('/');
  function submit(message: string) {
    return (e: FormEvent) => {
      e.preventDefault();
      window.open(whatsappUrl(message), '_blank', 'noopener,noreferrer');
      setSent(true);
    };
  }
  return { name, setName, date, setDate, time, setTime, notes, setNotes, sent, fmt, submit };
}

export function TastingForm() {
  const s = useSchedule();
  const message = [
    'Olá, Buffet Realeza! Quero agendar uma degustação para um casal.',
    `Nome: ${s.name}`,
    `Data desejada: ${s.fmt(s.date)}`,
    `Horário desejado: ${s.time}`,
    s.notes ? `Observações: ${s.notes}` : '',
    `Investimento: R$ ${TASTING.pricePerCouple.toLocaleString('pt-BR')},00 por casal, integralmente descontados do contrato ao fechar o evento.`,
    'Aguardo a confirmação da disponibilidade para o agendamento.',
  ].filter(Boolean).join('\n');
  return <form className="quote-form" onSubmit={s.submit(message)}>
    <h2 className="mb-6 font-display text-3xl">Agende sua degustação</h2>
    <label>Seu nome<input required value={s.name} onChange={e => s.setName(e.target.value)} /></label>
    <label className="mt-5 block">Data desejada<input required type="date" value={s.date} onChange={e => s.setDate(e.target.value)} /></label>
    <label className="mt-5 block">Horário desejado<select required value={s.time} onChange={e => s.setTime(e.target.value)}><option value="">Selecione um horário</option>{TIMES.map(t => <option key={t}>{t}</option>)}</select></label>
    <label className="mt-5 block">Observações<textarea rows={4} value={s.notes} onChange={e => s.setNotes(e.target.value)} placeholder="Restrições alimentares ou outra informação" /></label>
    <Button type="submit" className="mt-6 h-auto min-h-12 w-full whitespace-normal py-3"><Send />Solicitar agendamento no WhatsApp</Button>
    {s.sent && <p role="status" className="mt-4 flex items-center gap-2 text-sm text-primary"><Check className="h-4 w-4" />Mensagem preparada. O buffet confirmará a disponibilidade.</p>}
  </form>;
}

export function KidsScheduleForm() {
  const s = useSchedule();
  const message = [
    'Olá, Buffet Realeza! Quero agendar a festa dos pequenos (Evento Kids).',
    `Nome: ${s.name}`,
    `Data desejada: ${s.fmt(s.date)}`,
    `Horário desejado: ${s.time}`,
    s.notes ? `Observações: ${s.notes}` : '',
    'Aguardo a confirmação da disponibilidade para o agendamento.',
  ].filter(Boolean).join('\n');
  return <form className="quote-form" onSubmit={s.submit(message)}>
    <h2 className="mb-6 font-display text-3xl">Escolha a data e o horário</h2>
    <label>Seu nome<input required value={s.name} onChange={e => s.setName(e.target.value)} /></label>
    <label className="mt-5 block">Data desejada<input required type="date" value={s.date} onChange={e => s.setDate(e.target.value)} /></label>
    <label className="mt-5 block">Horário desejado<select required value={s.time} onChange={e => s.setTime(e.target.value)}><option value="">Selecione um horário</option>{TIMES.map(t => <option key={t}>{t}</option>)}</select></label>
    <label className="mt-5 block">Observações<textarea rows={4} value={s.notes} onChange={e => s.setNotes(e.target.value)} placeholder="Tema da festa, idade do aniversariante ou outra informação" /></label>
    <Button type="submit" className="mt-6 h-auto min-h-12 w-full whitespace-normal py-3"><Send />Solicitar agendamento no WhatsApp</Button>
    {s.sent && <p role="status" className="mt-4 flex items-center gap-2 text-sm text-primary"><Check className="h-4 w-4" />Mensagem preparada. O buffet confirmará a disponibilidade.</p>}
  </form>;
}
