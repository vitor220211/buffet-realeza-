import { useState } from 'react';
import { Link } from '@tanstack/react-router';
import { Menu, X, Send } from 'lucide-react';
import logo from '@/assets/novas/logo-correct.jpg.asset.json';
import { Button } from '@/components/ui/button';
export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const links = [['/', 'Buffet'], ['/personalize', 'Personalize seu cardápio'], ['/kids', 'Eventos Kids'], ['/degustacao', 'Degustação']] as const;
  return <header className="site-header sticky top-0 z-40 border-b bg-background/95 backdrop-blur"><div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-5 py-3">
    <Link to="/" className="flex shrink-0 items-center gap-3"><img src={logo.url} alt="Logo Buffet Realeza" className="h-12 w-12 rounded-full" /><span className="font-display text-xl sm:text-2xl">Buffet <span className="text-primary">Realeza</span></span></Link>
    <nav className="hidden items-center gap-1 lg:flex">{links.map(([to, label]) => <Button key={to} asChild variant="ghost"><Link to={to} activeProps={{ className: 'text-primary' }} activeOptions={{ exact: true }}>{label}</Link></Button>)}</nav>
    <Button asChild className="hidden sm:inline-flex"><Link to="/personalize"><Send /> Orçamento</Link></Button>
    <Button variant="ghost" size="icon" className="lg:hidden" aria-label={open ? 'Fechar menu' : 'Abrir menu'} aria-expanded={open} onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</Button>
  </div>{open && <nav className="flex flex-col border-t p-3 lg:hidden">{links.map(([to, label]) => <Button key={to} asChild variant="ghost" className="justify-start" onClick={() => setOpen(false)}><Link to={to}>{label}</Link></Button>)}</nav>}</header>;
}