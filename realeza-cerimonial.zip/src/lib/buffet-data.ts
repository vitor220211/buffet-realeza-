export const welcome = ["Água aromatizada de hortelã e limão", "Água mineral e com gás", "Refrigerantes tradicionais e zero (Coca-Cola e Guaraná Antarctica)", "Suco natural de abacaxi com hortelã"];

type Proposta = { nome: string; destaque?: boolean; secoes: [string, string][] };
export const propostas: Proposta[] = [
  {
    nome: "Diamante", destaque: true,
    secoes: [
      ["Ilha de Frios – Seleção Diamante", "Queijo Gouda Holandês, Brie com favo de mel, Brie com geleia de morango, Brie com damasco, Gorgonzola, Parmesão, Provolone e Mussarela • Salame italiano, copa, peito de peru e presunto especial"],
      ["Antepastos e Especialidades", "Tomate seco, kibe cru, coalhada seca, pasta de azeitonas chilenas, pasta de mostarda e mel, patê de frango especial, azeitonas, salada na taça, peras ao vinho"],
      ["Terrines Especiais", "Terrine de queijo, de tomate seco, de presunto Parma, tortelli de frango e palmito • Cesto de pães artesanais e torradas"],
      ["Jantar", "Filé ao molho marsala com champignons, rondelli de presunto e queijo, filé de frango ao creme de pupunha com catupiry, arroz neve, salada mista Realeza"],
      ["Sobremesa", "Bolo especial (um sabor à escolha)"],
    ],
  },
  {
    nome: "Gold",
    secoes: [
      ["Ilha de Frios – Seleção Especial", "Queijo Gouda Holandês, Brie com favo de mel, Gorgonzola, Parmesão, Provolone e Mussarela • Salame italiano, copa, peito de peru e presunto especial"],
      ["Acompanhamentos e Antepastos", "Tomate seco, kibe cru, coalhada seca, pasta de azeitonas chilenas, pasta de mostarda e mel, patê de frango, azeitonas, salada Caesar na taça, pães artesanais e torradas"],
      ["Jantar", "Filé ao molho marsala com champignons, rondelli de presunto e queijo, filé de frango ao creme de pupunha com catupiry, arroz neve, salada mista Realeza"],
      ["Sobremesa", "Bolo especial (um sabor à escolha)"],
    ],
  },
  {
    nome: "Experiência",
    secoes: [
      ["Entrada – Ilha de Frios", "Queijo Gouda Holandês, Brie com favo de mel, Gorgonzola, Parmesão, Provolone e Mussarela • Salame italiano, copa, peito de peru e presunto especial"],
      ["Antepastos", "Tomate seco, kibe cru, coalhada seca, pastas, patê de frango, azeitonas, salada Caesar na taça, pães artesanais e torradas"],
      ["Finger Foods – Experiência Gastronômica", "Escondidinho de carne seca, mignon ao marsala com arroz de amêndoas, mignon ao gorgonzola com farfalle, tiras de frango ao creme de pupunha, penne com brócolis e bacon, risoto de limão siciliano com salmão"],
      ["Sobremesa", "Bolo especial (um sabor à escolha)"],
    ],
  },
  {
    nome: "Brasa",
    secoes: [
      ["Entrada", "Torradas com dois tipos de patê • Tábua de frios: queijo prato, mussarela, salame, peito de peru, presunto e azeitonas"],
      ["Jantar – Estação de Espetinhos", "Arroz branco, mandioca salteada com alho e bacon, vinagrete, farofa especial, salpicão"],
      ["Espetinhos Especiais", "Cordão de mignon, fraldinha, kafta, linguiça artesanal, medalhão de frango e queijo coalho"],
      ["Sobremesa", "Bolo especial (um sabor à escolha)"],
    ],
  },
  {
    nome: "Itália",
    secoes: [
      ["Entrada – Ilha de Frios", "Queijo Gouda Holandês, Brie com favo de mel, Gorgonzola, Parmesão, Mussarela • Salame, copa, peito de peru, presunto especial"],
      ["Antepastos", "Kibe cru, pasta de azeitonas chilenas, pasta de mostarda e mel, patê de frango, azeitonas, salada Caesar na taça, pães e torradas"],
      ["Festival de Massas", "Rondelli de presunto e queijo, sofiatelli de frango, penne, fusilli e talharim • Molhos sugo, bolonhesa e branco • Bacon, azeitonas, frango desfiado, milho, ervilha, brócolis, calabresa"],
      ["Sobremesa", "Bolo especial (um sabor à escolha)"],
    ],
  },
  {
    nome: "Bistrô Brasileiro",
    secoes: [
      ["Entrada – Ilha de Frios", "Queijo Gouda Holandês, Brie com favo de mel, Gorgonzola, Parmesão e Mussarela • Salame, copa, peito de peru, presunto especial"],
      ["Antepastos", "Kibe cru, pasta de azeitonas chilenas, pasta de mostarda e mel, patê de frango, azeitonas, salada Caesar na taça, pães e torradas"],
      ["Estação de Petiscos Gourmet", "Mini pastéis de queijo e carne, coxinha de frango, rissoles, bolinha de queijo, calabresa acebolada, mandioca frita, batata frita, frango a passarinho, dadinho de tapioca"],
    ],
  },
  {
    nome: "Prata",
    secoes: [
      ["Entrada – Tábuas de Frios", "Queijo prato, mussarela, salame, peito de peru, presunto e azeitonas selecionadas"],
      ["Jantar", "Filé ao molho marsala com champignons, penne com brócolis e bacon, batata gratinada, arroz neve, salada mista Realeza"],
      ["Sobremesa", "Bolo especial (um sabor à escolha)"],
    ],
  },
];

