// Opções de pacote para festas infantis. Os nomes e valores dos pacotes exclusivos
// são enviados pelo Buffet Realeza, então nada aqui traz preço.
export const KIDS_EXCLUSIVE_PACKAGE = 'Pacote exclusivo — festa infantil';

export const kidsProposalOptions = [
  KIDS_EXCLUSIVE_PACKAGE,
  'Ainda não sei — quero conhecer os pacotes exclusivos',
];
