export const WHATSAPP_NUMBER = '5514982182008';
export const TASTING = { pricePerCouple: 200, contractCredit: 200, appointmentRequired: true };
export type EventQuote = {
  name: string; date: string; guests: string; location: string; eventType: string;
  proposal: string; changes: string[]; notes: string; childrenFree?: string; childrenHalf?: string;
};
export function whatsappUrl(message: string) {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}
export function quoteMessage(q: EventQuote) {
  const date = q.date.split('-').reverse().join('/');
  return [
    'Olá, Buffet Realeza! Gostaria de um orçamento para meu evento.',
    `Nome: ${q.name}`, `Data do evento: ${date}`, `Tipo de evento: ${q.eventType}`,
    `Quantidade de convidados: ${q.guests}`, `Local do evento: ${q.location}`,
    `Proposta escolhida: ${q.proposal}`,
    ...(q.childrenFree ? [`Crianças de 0 a 3 anos (não pagam): ${q.childrenFree}`] : []),
    ...(q.childrenHalf ? [`Crianças de 4 a 8 anos (meia): ${q.childrenHalf}`] : []),
    'Personalização do cardápio:', ...(q.changes.length ? q.changes.map(c => `• ${c}`) : ['• Manter o cardápio da proposta']),
    ...(q.notes.trim() ? [`Outras escolhas e trocas: ${q.notes.trim()}`] : []),
    'Por favor, informe o orçamento e os valores dos acréscimos e das trocas escolhidas.'
  ].join('\n');
}
export function kidsBillingWeight(age: number) { return age <= 3 ? 0 : age <= 8 ? 0.5 : 1; }
export const KIDS_MINIMUM_PAYING_GUESTS = 80;